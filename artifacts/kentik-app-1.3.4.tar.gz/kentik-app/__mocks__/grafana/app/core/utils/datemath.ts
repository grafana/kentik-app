export default {
  parse: jest.fn()
}
