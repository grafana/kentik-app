declare module '*.html' {
  const value: any;
  export default value;
}
