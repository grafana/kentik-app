export class ConfigCtrl {
  static templateUrl = 'datasource/config.html';
}
